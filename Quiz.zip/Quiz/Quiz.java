import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

public class Quiz {
    public static int domanda_corrente = 0;
    public static JRadioButton[][] radioButtons;
    public static JButton pulsanteInvia;
    public static JButton pulsanteMostraPunteggio;
    public static JPanel panelloDomande;
    public static Vector<String> risposteSalvate = new Vector<>();
    public static JPanel panelloRisposte;
    public static CardLayout cl;

    public static void main(String[] args) {
        Vector<Domanda> domande = new Vector<>();
        leggiDomandeDaFile(domande);

        if (domande.isEmpty()) System.out.println("Nessuna domanda trovata.");

        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Quiz");
        frame.setSize(1000, 1000);
        frame.setLayout(new BorderLayout());

        // pannelli
        JPanel panelloSuperiore = new JPanel(new FlowLayout());
        frame.add(panelloSuperiore, BorderLayout.NORTH);

        JPanel panelloCentrale = new JPanel(new CardLayout());
        cl = (CardLayout) panelloCentrale.getLayout();
        frame.add(panelloCentrale, BorderLayout.CENTER);

        JPanel panelloInferiore = new JPanel(new FlowLayout());
        frame.add(panelloInferiore, BorderLayout.SOUTH);

        JLabel labelNome = new JLabel("Nome:");
        panelloSuperiore.add(labelNome);

        JTextField textFieldNome = new JTextField(20);
        panelloSuperiore.add(textFieldNome);

        JLabel labelCognome = new JLabel("Cognome:");
        panelloSuperiore.add(labelCognome);

        JTextField textFieldCognome = new JTextField(20);
        panelloSuperiore.add(textFieldCognome);

        JLabel labelClasse = new JLabel("Classe:");
        panelloSuperiore.add(labelClasse);

        JTextField textFieldClasse = new JTextField(20);
        panelloSuperiore.add(textFieldClasse);

        panelloDomande = new JPanel(new GridBagLayout());

        JScrollPane scrollPane = new JScrollPane(panelloDomande);
        panelloCentrale.add(scrollPane, "domande");

        panelloRisposte = new JPanel(new GridBagLayout());
        JScrollPane scrollPaneRisposte = new JScrollPane(panelloRisposte);
        panelloCentrale.add(scrollPaneRisposte, "risposte");

        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.insets = new Insets(10, 10, 10, 10);

        domanda_corrente = 0;
        radioButtons = new JRadioButton[domande.size()][3];
        mostraDomanda(domande, panelloDomande, c, domanda_corrente);

        // bottone avanti
        JButton pulsanteAvanti = new JButton("Avanti");
        panelloInferiore.add(pulsanteAvanti);
        pulsanteAvanti.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Salvataggio della risposta corrente, anche se vuota
                salvaRisposta();
                domanda_corrente++;
                if (domanda_corrente < domande.size()) {
                    mostraDomanda(domande, panelloDomande, c, domanda_corrente);
                    cl.show(panelloCentrale, "domande");
                } else {
                    JOptionPane.showMessageDialog(frame, "Hai risposto a tutte le domande.");
                    domanda_corrente = 0;
                    mostraDomanda(domande, panelloDomande, c, domanda_corrente);
                    cl.show(panelloCentrale, "domande");
                }
            }
        });

        // bottone indietro
        JButton pulsanteIndietro = new JButton("Indietro");
        panelloInferiore.add(pulsanteIndietro);
        pulsanteIndietro.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                domanda_corrente--;
                if (domanda_corrente >= 0) {
                    mostraDomanda(domande, panelloDomande, c, domanda_corrente);
                    cl.show(panelloCentrale, "domande");
                }
            }
        });

        // bottone invia
        pulsanteInvia = new JButton("Invia");
        panelloInferiore.add(pulsanteInvia);
        pulsanteInvia.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                salvaRisposta();
                String dataOdierna = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
                mostraRisposte(domande, textFieldNome.getText(), textFieldCognome.getText(), textFieldClasse.getText(), dataOdierna);
                pulsanteInvia.setEnabled(false);
                pulsanteAvanti.setEnabled(false);
                pulsanteIndietro.setEnabled(false);
                textFieldNome.setEnabled(false);
                textFieldCognome.setEnabled(false);
                textFieldClasse.setEnabled(false);
                cl.show(panelloCentrale, "risposte");
            }
        });

        // bottone mostra punteggio
        pulsanteMostraPunteggio = new JButton("Mostra Punteggio");
        panelloInferiore.add(pulsanteMostraPunteggio);
        pulsanteMostraPunteggio.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int punteggio = calcolaPunteggio(domande);
                double percentuale = ((double) punteggio / domande.size()) * 100;
                JOptionPane.showMessageDialog(frame, "Punteggio: " + punteggio + "/" + domande.size() + " (" + percentuale + "%)");
            }
        });

        frame.setVisible(true);
    }

    // mostra le domande
    public static void mostraDomanda(Vector<Domanda> domande, JPanel panello, GridBagConstraints c, int index) {
        panello.removeAll();
        Domanda domanda = domande.get(index);

        c.gridx = 0;
        c.gridy = 0;
        JLabel etichettaDomanda = new JLabel(domanda.getTestoDomanda());
        etichettaDomanda.setForeground(Color.BLACK);
        etichettaDomanda.setFont(etichettaDomanda.getFont().deriveFont(Font.BOLD, 16));
        panello.add(etichettaDomanda, c);

        ButtonGroup gruppoPulsanti = new ButtonGroup();
        for (int j = 0; j < 3; j++) {
            c.gridx = 0;
            c.gridy++;
            radioButtons[index][j] = new JRadioButton(domanda.getOpzione(j));
            radioButtons[index][j].setHorizontalAlignment(SwingConstants.LEFT);
            radioButtons[index][j].setFont(radioButtons[index][j].getFont().deriveFont(16f));
            panello.add(radioButtons[index][j], c);
            gruppoPulsanti.add(radioButtons[index][j]);
        }

        panello.revalidate();
        panello.repaint();
    }

    // salva risposte
    public static void salvaRisposta() {
        String risposta = "";
        for (int j = 0; j < 3; j++) {
            if (radioButtons[domanda_corrente][j].isSelected()) {
                risposta += j + ";" + radioButtons[domanda_corrente][j].getText() + ";";
            }
        }
        risposteSalvate.add(risposta);
    }

    // calcola punteggio
    public static int calcolaPunteggio(Vector<Domanda> domande) {
        int punteggio = 0;
        for (int i = 0; i < radioButtons.length; i++) {
            for (int j = 0; j < 3; j++) {
                if (radioButtons[i][j].isSelected() && j == domande.get(i).getRispostaCorretta() - 1) {
                    punteggio++;
                }
            }
        }
        return punteggio;
    }

    // leggi domande
    public static void leggiDomandeDaFile(Vector<Domanda> domande) {
        String filePath = "Informatica/Java_interfacce_grafiche/Quiz/domande.csv";
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] dati = linea.split(",");
                String testoDomanda = dati[0];
                String[] opzioni = {dati[1], dati[2], dati[3]};
                int rispostaCorretta = 0;

                try {
                    rispostaCorretta = Integer.valueOf(dati[4]);
                } catch (NumberFormatException j) {
                    j.printStackTrace();
                }

                domande.add(new Domanda(testoDomanda, opzioni, rispostaCorretta));
            }
        } catch (IOException e) {
            System.out.println("Errore durante la lettura delle domande: " + e.getMessage());
        }
    }

    // mostra risposte in una nuova pagina
    public static void mostraRisposte(Vector<Domanda> domande, String nome, String cognome, String classe, String dataOdierna) {
        panelloRisposte.removeAll();

        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.insets = new Insets(10, 10, 10, 10);

        JLabel etichettaTitolo = new JLabel("Risposte di " + nome + " " + cognome + " della classe " + classe + " - " + dataOdierna);
        etichettaTitolo.setForeground(Color.BLACK);
        etichettaTitolo.setFont(etichettaTitolo.getFont().deriveFont(Font.BOLD, 16));
        panelloRisposte.add(etichettaTitolo, c);
        c.gridy++;

        for (int i = 0; i < domande.size(); i++) {
            Domanda domanda = domande.get(i);
            String risposta = "Non risposto";
            String stato = "Non risposto";

            for (int j = 0; j < 3; j++) {
                if (radioButtons[i][j].isSelected()) {
                    risposta = radioButtons[i][j].getText();
                    stato = (j == domande.get(i).getRispostaCorretta() - 1) ? "Corretta" : "Sbagliata (Corretta: " + domande.get(i).getOpzione(domande.get(i).getRispostaCorretta() - 1) + ")";
                }
            }

            JLabel etichettaDomanda = new JLabel("Domanda " + ": " + domanda.getTestoDomanda());
            etichettaDomanda.setForeground(Color.BLACK);
            etichettaDomanda.setFont(etichettaDomanda.getFont().deriveFont(Font.BOLD, 14));
            panelloRisposte.add(etichettaDomanda, c);
            c.gridy++;

            JLabel etichettaRisposta = new JLabel("Risposta: " + risposta + ", Stato: " + stato);
            etichettaRisposta.setForeground(Color.BLACK);
            etichettaRisposta.setFont(etichettaRisposta.getFont().deriveFont(14f));
            panelloRisposte.add(etichettaRisposta, c);
            c.gridy++;
        }

        panelloRisposte.revalidate();
        panelloRisposte.repaint();
    }
}